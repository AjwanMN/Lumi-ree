from django.db import models

# Create your models here.

class product(models.Model):
    name = models.CharField(max_length=200)
    description = models.TextField()
    price = models.DecimalField(max_digits=6, decimal_places=2)
    pic= models.ImageField(upload_to='pics/%Y/%m/%d/')
    
    def __str__(self):
        return self.name