from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def index(request):
    return render(request, 'pages/homePage.html')

def products(request):
    return render(request, 'pages/Version2.html')

def sign(request):
    return render(request, 'pages/accounts/sign.html')

# add cart def and in url.page
def cart(request):
    return render(request, 'pages/cart.html')