from django.urls import path
from . import views

urlpatterns = [
    path( '', views.index, name = 'index'),
    path( 'products', views.products, name = 'products'),
    path( 'sign', views.sign, name='sign'),
    path( 'cart', views.cart, name='cart'),
]