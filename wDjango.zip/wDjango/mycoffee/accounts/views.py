from django.shortcuts import render

# Create your views here.

def sign(request):
    return render( request, 'accounts/sign.html')

